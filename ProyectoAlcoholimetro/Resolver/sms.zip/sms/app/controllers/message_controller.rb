class MessageController < ApplicationController
	def index
		@message = Message.all.order(:id)
		respond_with @message
	end
	def show
		@message = Message.find params[:id]
		respond_with @message
	end
	def create
		@message = Message.new message_params
		if @message.save!
			respond_with @message, status: :created, location: @message
		else
			respond_with @message, status: :unprocessable_entity
		end
	end
	def update
		@message = Message.find params[:id]
		if message.update_attributes!(message_params)
			respond_with @message, status: :ok, location: @message
		else
			respond_with @message, status: :unprocessable_entity
		end
	end
	def destroy
		@message = Message.find params[:id]
		if message.destroy
			render json: {status: :ok}
		else
			respond_with @message, status: :unprocessable_entity
		end
	end
	def last
		@message = Message.last
		respond_with @message
	end
	protected
	def message_params
		params.require(:message).permit(:message)
	end
end
