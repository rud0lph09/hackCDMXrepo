//
//  AppDelegate.h
//  Podium_Comunication
//
//  Created by Mario on 07/08/14.
//  Copyright (c) 2014 UNAM Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
