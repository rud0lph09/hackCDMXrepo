//
//  ViewController.m
//  Alcoholimetro
//
//  Created by Mario on 07/03/15.
//  Copyright (c) 2015 Bambú Mobile. All rights reserved.
//

#import "ViewController.h"
#define LENGTH_BUF 1

@interface ViewController ()

@end

@implementation ViewController
@synthesize rssiLabel;
@synthesize buttonConectarBLE;
@synthesize ble;


- (void)viewDidLoad
{
    [super viewDidLoad];

    self.ble = [[BLE alloc]init];
    [self.ble controlSetup];
    self.ble.delegate = self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)bleDidReceiveData:(unsigned char *)data length:(int)length{
    
    //NSData *d = [NSData dataWithBytes: data length:length];
    NSMutableArray *datos = [NSMutableArray arrayWithCapacity:length];
    //int enteros[length];
    //NSArray
    
    for (NSInteger i=0; i<length; i++) {
        unsigned int result = 0;
        NSScanner *scanner = [NSScanner scannerWithString:[NSString stringWithFormat:@"%02x",data[i]]];
        [scanner setScanLocation:0];
        [scanner scanHexInt:&result];
        
        [datos addObject:[NSNumber numberWithInt:result]];
        //enteros[i] = result;
        //[datos addObject:[NSString stringWithFormat:@"%@",datos[i]]];
    }
    
    self.acelerometroLabel.text = [NSString stringWithFormat:@" de alcohol en la sangre:  %@",datos[0]];
    self.giroscopioLabel.text = [NSString stringWithFormat:@"       Puedes conducir:  %@",datos[1]];
    
    NSLog(@"tamaño: %d",length);
    NSLog(@"  data: %s",data);
    //NSLog(@"     d: %@",d);
    NSLog(@" datos: %@",datos);
    
}



-(void)bleDidUpdateRSSI:(NSNumber *)rssi{
    self.rssiLabel.text = [NSString stringWithFormat:@"RSSI: %@", rssi];
}

-(void) readRSSITimer:(NSTimer *)timer
{
    [self.ble readRSSI];
}

#pragma mark - BLE Actions
-(void)scanForPeripherals:(id)sender{
    
    if(self.ble.peripherals){
        self.ble.peripherals = nil;
    }
    
    [self.ble findBLEPeripherals:2];
    [NSTimer scheduledTimerWithTimeInterval:(float)1.0 target:self selector:@selector(connectionTimer:) userInfo:nil repeats:NO];
}

-(void)disconnectFromPeripheral{
    if(self.ble.activePeripheral){
        if (self.ble.activePeripheral.state) {
            [[self.ble CM] cancelPeripheralConnection:[self.ble activePeripheral]];
            
        }
    }
}

-(void)connectionTimer:(NSTimer*)timer{
    
    if(self.ble.peripherals.count > 0){
        [self.ble connectPeripheral:[self.ble.peripherals objectAtIndex:0]];
    }else{
        NSLog(@"Conexión Perdida");
    }
}

-(void)bleDidConnect{
    [self.buttonConectarBLE setTitle:@"Desconectar" forState:UIControlStateNormal];
    [self.buttonConectarBLE removeTarget:self action:@selector(scanForPeripherals:) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonConectarBLE addTarget:self action:@selector(disconnectFromPeripheral) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonConectarBLE setEnabled:YES];
}

-(void)bleDidDisconnect{
    self.rssiLabel.text = @"RSSI: --";
    [self.buttonConectarBLE setTitle:@"Conectar BLE" forState:UIControlStateNormal];
    [self.buttonConectarBLE removeTarget:self action:@selector(disconnectFromPeripheral) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonConectarBLE addTarget:self action:@selector(scanForPeripherals:) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonConectarBLE setEnabled:YES];
    
}

- (IBAction)conectarBLE:(id)sender {
    [self scanForPeripherals:self];
}



@end
