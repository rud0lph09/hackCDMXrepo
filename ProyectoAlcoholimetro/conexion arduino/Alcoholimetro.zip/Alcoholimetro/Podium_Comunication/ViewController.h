//
//  ViewController.h
//  Podium_Comunication
//
//  Created by Mario on 07/03/15.
//  Copyright (c) 2015 Bambú Mobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BLE.h"

@interface ViewController : UIViewController<BLEDelegate>

@property (nonatomic, strong) BLE *ble;

@property (weak, nonatomic) IBOutlet UILabel *acelerometroLabel;
@property (weak, nonatomic) IBOutlet UILabel *giroscopioLabel;

@property (weak, nonatomic) IBOutlet UILabel *rssiLabel;
@property (weak, nonatomic) IBOutlet UIButton *buttonConectarBLE;

- (IBAction)conectarBLE:(id)sender;


@end
